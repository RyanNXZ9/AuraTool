# Aura Tool

Plugin local para Vencord no Windows. Personaliza avatar, moldura, banner, efeito, cores, insígnias, nomes e conexões no cliente em que está instalado.

## Instalação

1. Tenha um checkout do [Vencord](https://github.com/Vendicated/Vencord), além de Git, Node.js e a versão do pnpm indicada no `package.json` do checkout.
2. Baixe e extraia o projeto. Execute `install.bat`. Ele procura o checkout nas pastas usuais e copia o plugin para `src/userplugins/AuraTool` antes de compilar.
3. Recarregue o Discord. Em **Configurações → Vencord Settings → Plugins**, ative **Aura Tool**. Abra o botão de informações do cartão para acessar o painel.

Para escolher um checkout ou testar a detecção sem copiar arquivos:

```powershell
.\install.bat -VencordPath "D:\Projetos\Vencord"
.\install.bat -WhatIf
```

Se o Discord ainda não carregar esse checkout, execute `install.bat -Inject` para abrir o fluxo de instalação do próprio Vencord. Para atualizar o Aura Tool, execute o instalador novamente a partir da fonte atualizada.

## Personalização

- **Perfil** aceita GIF ou imagem no avatar, moldura, banner, efeito visual e tema de duas cores.
- **Insígnias** usa a fileira de insígnias do perfil e permite escolher variantes de vários níveis.
- **Conexões** oferece modelos editáveis e links personalizados.

Os cosméticos são locais. As variantes de insígnias consultam [o arquivo público de ícones](https://github.com/mezotv/discord-badges).

